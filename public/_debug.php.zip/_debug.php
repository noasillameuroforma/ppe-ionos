<?php
declare(strict_types=1);

$files = [
  __DIR__ . '/php-fatal.log',
  __DIR__ . '/php-error.log',
  __DIR__ . '/login-step.log',
  __DIR__ . '/debug.log',
];

header('Content-Type: text/plain; charset=utf-8');

foreach ($files as $f) {
    echo "===== " . basename($f) . " =====\n";
    if (is_file($f)) {
        echo substr(file_get_contents($f), -20000);
        echo "\n\n";
    } else {
        echo "absent\n\n";
    }
}
